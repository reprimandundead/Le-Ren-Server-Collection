#include "/lib/colors/skyColors.glsl"

// Colored, subtly varied and gently humming stars.
// The original Complementary star generation/fading logic is preserved.

float GetStarNoise(vec2 pos) {
    return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.54953);
}

vec2 GetStarCoord(vec3 viewPos, float sphereness) {
    vec3 wpos = normalize((gbufferModelViewInverse * vec4(viewPos * 1000.0, 1.0)).xyz);
    vec3 starCoord = wpos / (wpos.y + length(wpos.xz) * sphereness);
    starCoord.x += 0.006 * syncedTime;
    return starCoord.xz;
}

vec3 GetStarColor(vec2 starCoord) {
    // Match the same 1024-cell quantization used by the star generator.
    vec2 cell = floor(starCoord * 1024.0) / 1024.0;

    // One value chooses the color family; separate values create tiny
    // per-star RGB differences without changing the family noticeably.
    float r = GetStarNoise(cell + 17.31);
    float vr = GetStarNoise(cell + 43.72) - 0.5;
    float vg = GetStarNoise(cell + 91.46) - 0.5;
    float vb = GetStarNoise(cell + 137.83) - 0.5;

    vec3 color;

    // 48% normal blue
    if (r < 0.48) {
        color = vec3(0.70, 0.70, 1.00);
    }
    // 12% stronger blue
    else if (r < 0.60) {
        color = vec3(0.30, 0.50, 1.00);
    }
    // 10% aqua
    else if (r < 0.70) {
        color = vec3(0.20, 0.90, 1.00);
    }
    // 7% green
    else if (r < 0.77) {
        color = vec3(0.25, 0.95, 0.35);
    }
    // 7% yellow
    else if (r < 0.84) {
        color = vec3(1.00, 0.90, 0.20);
    }
    // 5% purple
    else if (r < 0.89) {
        color = vec3(0.75, 0.30, 1.00);
    }
    // 4% pink
    else if (r < 0.93) {
        color = vec3(1.00, 0.30, 0.65);
    }
    // 4% orange
    else if (r < 0.97) {
        color = vec3(1.00, 0.45, 0.15);
    }
    // 3% red
    else {
        color = vec3(1.00, 0.20, 0.20);
    }

    // Very small per-star variation, equivalent to the 0.025 variation
    // from the standalone shader we built earlier.
    color += vec3(vr, vg, vb) * 0.025;
    return clamp(color, vec3(0.0), vec3(1.0));
}

vec3 GetStars(vec2 starCoord, float VdotU, float VdotS) {
    #if NIGHT_STAR_AMOUNT == 0
        return vec3(0.0, 0.0, 0.0);
    #endif
    if (VdotU < 0.0) return vec3(0.0);

    starCoord *= 0.2;
    float starFactor = 1024.0;
    starCoord = floor(starCoord * starFactor) / starFactor;

    float star = 1.0;
    star *= GetStarNoise(starCoord.xy);
    star *= GetStarNoise(starCoord.xy+0.1);
    star *= GetStarNoise(starCoord.xy+0.23);

    #if NIGHT_STAR_AMOUNT == 1
        star -= 0.82;
        star *= 2.0;
    #elif NIGHT_STAR_AMOUNT == 2
        star -= 0.7;
    #elif NIGHT_STAR_AMOUNT == 3
        star -= 0.62;
        star *= 0.75;
    #elif NIGHT_STAR_AMOUNT == 4
        star -= 0.52;
        star *= 0.55;
    #endif
    star = max0(star);
    star *= star;

    // Keep Complementary's original horizon/sun/rain/night fading.
    star *= min1(VdotU * 3.0) * max0(1.0 - pow(abs(VdotS) * 1.002, 100.0));
    star *= invRainFactor * pow2(pow2(invNoonFactor2)) * (1.0 - 0.5 * sunVisibility);

    // Gentle humming: each star gets its own fixed phase, while the whole
    // effect remains synchronized to world time. The range is intentionally
    // small so Complementary's original star intensity remains dominant.
    float phase = GetStarNoise(starCoord.xy + 0.57) * 6.28318530718;
    float pulse = 0.925 + 0.075 * (0.5 + 0.5 * sin(syncedTime * 2.5 + phase));

    return 40.0 * star * pulse * GetStarColor(starCoord);
}
