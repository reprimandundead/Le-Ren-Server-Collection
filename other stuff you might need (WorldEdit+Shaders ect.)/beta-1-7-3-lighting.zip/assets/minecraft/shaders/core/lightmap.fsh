#version 150

layout(std140) uniform LightmapInfo {
    float AmbientLightFactor;
    float SkyFactor;
    float BlockFactor;
    int UseBrightLightmap;
    float NightVisionFactor;
    float DarknessScale;
    float DarkenWorldFactor;
    float BrightnessFactor;
    vec3 SkyLightColor;
} lightmapInfo;

in vec2 texCoord;

out vec4 fragColor;

float get_brightness(float level) {
    float curved_level = level / (4.0 - 3.0 * level);
    return mix(curved_level, 1.0, lightmapInfo.AmbientLightFactor);
}

vec3 notGamma(vec3 x) {
    vec3 nx = 1.0 - x;
    return 1.0 - nx * nx * nx * nx;
}

bool fuzzyEquals(float a, float b) {
	return a - 0.01 < b && a + 0.001 > b;
}

float mapNum(float value, float inMin, float inMax, float outMin, float outMax) {
  return outMin + (outMax - outMin) * (value - inMin) / (inMax - inMin);
}

void main() {
    float block_brightness = texCoord.x;
    float sky_brightness = texCoord.y;
	
	sky_brightness = sky_brightness * (round(mapNum(lightmapInfo.SkyLightColor.r, 0.48, 1.0, 0.25, 1.0) * 16.0) / 16.0);

    // cubic nonsense, dips to yellowish in the middle, white when fully saturated
	float largestBrightness = max(block_brightness, sky_brightness);
	largestBrightness = largestBrightness * 1.06;
	largestBrightness = largestBrightness - 0.03;
	largestBrightness = 0.0281 * pow(1.25, largestBrightness * 16);
	largestBrightness = largestBrightness + 0.05;
	
	//if (fuzzyEquals(largestBrightness, 1.0 / 16.0 * 16.0)) {
	//	largestBrightness = 0.0;
	//}
	//largestBrightness = abs(largestBrightness - 0.0);
	/*if (largestBrightness > lightmapInfo.BrightnessFactor) {
		largestBrightness = 0.0;
	} else {
		largestBrightness = 1.0;
	}*/
	
	//check how dark it gets at night (night 48%, day 100%, beta 25% at night)
	/*if (lightmapInfo.SkyLightColor.r > lightmapInfo.BrightnessFactor) {
		largestBrightness = 0.0;
	} else {
		largestBrightness = 1.0;
	}*/
	
	
    vec3 color = vec3(
        largestBrightness,
        largestBrightness,
        largestBrightness
    );

	//color = vec3(lightmapInfo.SkyLightColor.r);
	
	/*
    if (lightmapInfo.UseBrightLightmap != 0) {
        color = mix(color, vec3(0.99, 1.12, 1.0), 0.25);
        color = clamp(color, 0.0, 1.0);
    } else {
        color += lightmapInfo.SkyLightColor * sky_brightness;
        color = mix(color, vec3(0.75), 0.04);

        vec3 darkened_color = color * vec3(0.7, 0.6, 0.6);
        color = mix(color, darkened_color, lightmapInfo.DarkenWorldFactor);
    }

    if (lightmapInfo.NightVisionFactor > 0.0) {
        // scale up uniformly until 1.0 is hit by one of the colors
        float max_component = max(color.r, max(color.g, color.b));
        if (max_component < 1.0) {
            vec3 bright_color = color / max_component;
            color = mix(color, bright_color, lightmapInfo.NightVisionFactor);
        }
    }

    if (lightmapInfo.UseBrightLightmap == 0) {
        color = clamp(color - vec3(lightmapInfo.DarknessScale), 0.0, 1.0);
    }

	vec3 notGamma = notGamma(color);
    color = mix(color, notGamma, lightmapInfo.BrightnessFactor);
    color = mix(color, vec3(0.75), 0.04);
	*/
	//color *= 100.0;
    color = clamp(color, 0.0, 1.0);

    fragColor = vec4(color, 1.0);
}
