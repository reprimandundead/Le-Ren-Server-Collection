#version 330

layout(std140) uniform LightmapInfo {
    float SkyFactor;
    float BlockFactor;
    float NightVisionFactor;
    float DarknessScale;
    float BossOverlayWorldDarkeningFactor;
    float BrightnessFactor;
    vec3 BlockLightTint;
    vec3 SkyLightColor;
    vec3 AmbientColor;
    vec3 NightVisionColor;
} lightmapInfo;

in vec2 texCoord;

out vec4 fragColor;

float get_brightness(float level) {
    return level / (4.0 - 3.0 * level);
}

vec3 notGamma(vec3 color) {
    float maxComponent = max(max(color.x, color.y), color.z);
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - maxInverted * maxInverted * maxInverted * maxInverted;
    return color * (maxScaled / maxComponent);
}

float parabolicMixFactor(float level) {
    return (2.0 * level - 1.0) * (2.0 * level - 1.0);
}

float mapNum(float value, float inMin, float inMax, float outMin, float outMax) {
  return outMin + (outMax - outMin) * (value - inMin) / (inMax - inMin);
}

//beta lighting function, each level is 80% of higher
float transform_brightness(float level) {
    return pow(0.8, (1.0-level)*15.0);
}

void main() {
    // Calculate block and sky brightness levels based on texture coordinates
    float block_level = round(floor(texCoord.x * 16)) / 15;
    float sky_level = round(floor(texCoord.y * 16)) / 15;

    //map sky color to value from 0 - 1 so we can use a linear sky brightness affected by time
    float sky_time_brightness = mapNum(lightmapInfo.SkyLightColor.r, 122.0 / 255.0, 1.0, 0.0, 1.0);
    sky_time_brightness = round(sky_time_brightness * 15.0) / 15.0;

    sky_level *= sky_time_brightness;

    // Calculate ambient color with or without night vision
    vec3 nightVisionColor = lightmapInfo.NightVisionColor * lightmapInfo.NightVisionFactor;
    float ambientValue = 0.05 + nightVisionColor.r;

    // finalize
	float largestBrightness = max(block_level,sky_level);

    largestBrightness = transform_brightness(largestBrightness);
    largestBrightness += ambientValue;

    vec3 color = vec3(
        largestBrightness,
        largestBrightness,
        largestBrightness
    );

    // Apply brightness
    color = clamp(color, 0.0, 1.0);

    fragColor = vec4(color, 1.0);
}
